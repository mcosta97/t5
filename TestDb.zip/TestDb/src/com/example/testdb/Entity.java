package com.example.testdb;

public abstract class Entity {
	private int id;
	
	public Entity(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public abstract boolean validar();
	
	public abstract boolean alta();
	
	public abstract boolean baja();
	
	public abstract boolean modificar();
	
	public abstract String recuperar();
}
