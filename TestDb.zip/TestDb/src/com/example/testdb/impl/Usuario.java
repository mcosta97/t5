package com.example.testdb.impl;

import com.example.testdb.Entity;
import com.example.testdb.db.SqliteDb;
import com.example.testdb.utils.Constantes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Usuario extends Entity {
	private String nombre;
	private String clave;

	private SqliteDb db;
	private SQLiteDatabase base;

	public Usuario(int id, String nombre, String clave, Context context) {
		super(id);
		db = new SqliteDb(context, "Prueba", null, 1);
		this.nombre = nombre;
		this.clave = clave;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	@Override
	public boolean validar() {
		return !nombre.equals("") && !clave.equals("");
	}

	@Override
	public boolean alta() {
		boolean pudo = true;
		try {
			ContentValues valores = new ContentValues();
			valores.put(Constantes.CAMPO_USUARIO_ID, getId());
			valores.put(Constantes.CAMPO_USUARIO_NOMBRE, nombre);
			valores.put(Constantes.CAMPO_USUARIO_CLAVE, clave);
			base = db.getWritableDatabase();
			base.insert(Constantes.TABLA_USUARIO, null, valores);
			base.close();
		} catch (Exception e) {
			pudo = false;
		}

		return pudo;
	}

	@Override
	public boolean baja() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modificar() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String recuperar() {
		try {
			base = db.getReadableDatabase();
			String[] columns = { Constantes.CAMPO_USUARIO_ID, Constantes.CAMPO_USUARIO_NOMBRE, Constantes.CAMPO_USUARIO_CLAVE };
			Cursor cursor = base.query(Constantes.TABLA_USUARIO, columns, null, null, null, null, null);
			StringBuffer buffer = new StringBuffer();
			while (cursor.moveToNext()) {
				int cid = cursor.getInt(cursor.getColumnIndex(Constantes.CAMPO_USUARIO_ID));
				String name = cursor.getString(cursor.getColumnIndex(Constantes.CAMPO_USUARIO_NOMBRE));
				String password = cursor.getString(cursor.getColumnIndex(Constantes.CAMPO_USUARIO_CLAVE));
				buffer.append(cid + "   " + name + "   " + password + " \n");
			}
			return buffer.toString();
		} catch (Exception e) {
			return "ERROR: " + e.getMessage();
		}
	}

}