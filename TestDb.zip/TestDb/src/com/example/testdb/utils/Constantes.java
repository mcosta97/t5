package com.example.testdb.utils;

public class Constantes {
	public static final String CAMPO_USUARIO_ID = "PERSONA_ID";
	public static final String CAMPO_USUARIO_NOMBRE = "USUARIO";
	public static final String CAMPO_USUARIO_CLAVE = "CLAVE";
	public static final String TABLA_USUARIO = "Usuario";
}
